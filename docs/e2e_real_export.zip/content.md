# document_001

- `document_id`: doc_2eefaa19dc65 · `job_id`: job_fe27066f79c7
- Trang PDF đã chọn: 6–6 (1 trang được yêu cầu, 1 trang có kết quả)
- **Trạng thái: Bản trích xuất nháp** (chưa duyệt độc lập).
- Phạm vi: chỉ chữ và công thức (`text_and_formulas_only`); chưa xử lý hình học/đồ thị.
- Lưu ý ranh giới: các trang không liên tiếp được giữ riêng theo số trang PDF; không tự nối đoạn qua khoảng trống.

## Trang PDF 6
### PHÂN THỐNG KÊ VÀ XÁC SUẤT

CHƯƠNG VI. THỐNG KÊ
Bài 1. Số gần đứng và sai số
Bài 2. Mô tả và biểu diễn đữ liệu trên các bảng và biểu đồ
Bài 3. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu
Bài 4. Các số đặc trưng đo mức độ phân tán của mẫu số liệu
Bài tập cuối chương VI
HOẠT ĐỘNG THỰC HÀNH VÀ TRẦI NGHIỆM
Bài 1. Dùng máy tính cảm tay để tính toán với số gần đứng và tính các số đặc trưng của mẫu số liệu thống kê
Bài 2. Dùng bảng tính để tính các số đặc trưng của mẫu số liệu thống kê
Bảng giải thích thuật ngữ
Bảng tra cứu thuật ngữ

### Chân trời sáng tạo

5

> Ranh giới trang: nội dung có thể tiếp tục ở trang khác chưa được chọn. Xem trang kề nếu cần.
